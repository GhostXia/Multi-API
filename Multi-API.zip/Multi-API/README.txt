# Multi-API 应用

## 使用说明

1. 双击 start.bat 启动Multi-API服务
2. 打开浏览器访问 http://localhost:3000 使用应用
3. 如需清理隐私数据，请运行 Clean-Privacy.exe

## 文件说明

- Multi-API.exe: 主程序
- Clean-Privacy.exe: 隐私数据清理工具
- start.bat: 启动脚本
- data/db.json: 数据库文件
- backups/: 备份目录
